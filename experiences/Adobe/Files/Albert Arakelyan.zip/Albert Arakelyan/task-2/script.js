const $clock = document.getElementById('clock');

function renderClock() {
  const time = new Date(Date.now()).toTimeString();
  const hours = +time.slice(0, 2);
  const minutes = +time.slice(3, 5);
  const seconds = +time.slice(6, 8);

  $clock.innerHTML = `${getNormalizedValue(hours)}:${getNormalizedValue(minutes)}:${getNormalizedValue(seconds)}`;
}

function getNormalizedValue(value) {
  return value.toString().length !== 2 ? `0${value}` : value.toString();
}

renderClock();

setInterval(renderClock, 1000);