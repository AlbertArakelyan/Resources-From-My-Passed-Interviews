//@TODO   Write code here to make `npm test` or `npm start` command pass

// export ...
export default function untitledModule(arr1, arr2) {
  if (!Array.isArray(arr1) || !Array.isArray(arr2)) {
    throw new TypeError('args must be arrays')
  }

  const isArr1AllNumbers = arr1.every(Number);
  const isArr2AllNumbers = arr2.every(Number);

  if (!isArr1AllNumbers || !isArr2AllNumbers) {
    throw new TypeError('all elements must be numbers')
  }

  for (let i = 0; i < arr1.length; i++) {
    if (arr1[i] > arr1[i + 1]) {
      throw new RangeError('arr1 is not sorted');
    }
  }

  for (let i = 0; i < arr2.length; i++) {
    if (arr2[i] > arr2[i + 1]) {
      throw new RangeError('arr2 is not sorted');
    }
  }

  return [...arr1, ...arr2];
}