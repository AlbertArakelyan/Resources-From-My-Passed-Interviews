import {jest} from '@jest/globals'

import untitledModule from '../src/untitledModule'

describe('untitledModule', () => {
  describe('Validate module and inputs', function () {
    it('is a function', () => {
      expect(typeof untitledModule).toBe('function')
    })

    it('throws an error if the first or second arguments are not an arrays', () => {
      expect(() => untitledModule('some string', [])).toThrow(TypeError);
      expect(() => untitledModule([1, 2], false)).toThrow(TypeError);
    });

    it('throws an error if one of the input arrays has a non-number element', () => {
      expect(() => untitledModule([0, 2], ['a', 3])).toThrow(TypeError);
      expect(() => untitledModule([], ['a', 3])).toThrow(TypeError);
      expect(() => untitledModule([5], [NaN, 3])).toThrow(TypeError);
      expect(() => untitledModule([-1, 2], [2, 8])).not.toThrow(TypeError);
    });

    it('throws an error if one of the input arrays are not properly sorted', () => {
      expect(() => untitledModule([3, 2], [5, 9, 20])).toThrow(RangeError);
      expect(() => untitledModule([3], [2, -4])).toThrow(RangeError);
      expect(() => untitledModule([3, 6], [2, 4])).not.toThrow(RangeError);
    });
  });

  describe('Correctly merge arrays', function () {
    it('returns a merged array', () => {
      expect(untitledModule([], [])).toEqual([]);
      expect(untitledModule([1, 2], [3, 4, 5])).toEqual([1, 2, 3, 4, 5]);
      expect(untitledModule([-6, -1, 1], [0, 2])).toEqual([-6, -1, 0, 1, 2]);
      expect(untitledModule([], [0, 2])).toEqual([0, 2]);
      expect(untitledModule([1, 2], [])).toEqual([1, 2]);
      expect(untitledModule([-2, 0], [0, 0, 4])).toEqual([-2, 0, 0, 0, 4]);
      expect(untitledModule([0, 0, 0], [0])).toEqual([0, 0, 0, 0]);
    });

    it('checks if Array.prototype.sort is not called', () => {
      const sortSpy = jest.spyOn(Array.prototype, 'sort');

      expect(untitledModule([5], [0, 8])).toEqual([0, 5, 8]);

      expect(sortSpy).not.toHaveBeenCalled();
    });
  })
})
