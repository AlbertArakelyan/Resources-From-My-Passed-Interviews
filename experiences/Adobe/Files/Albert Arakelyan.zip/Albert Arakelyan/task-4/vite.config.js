import { defineConfig } from 'vite'

export default defineConfig({
  root: 'src',
  publicDir: false,
  server: {
    port: 5284,
    open: true
  }
})
