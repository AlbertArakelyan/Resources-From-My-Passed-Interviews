import './index.css'
import './demo.css'

// if you use React
import bootstrap from "./react/Demo";

// if you use plain JavaScript
// import bootstrap from "./vanilla/Demo";

bootstrap(document.getElementById('root'))
