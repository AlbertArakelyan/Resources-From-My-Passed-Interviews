import React, { useState, useEffect, useRef, createRef } from 'react'
import { createRoot } from 'react-dom/client'


function Demo() {
  const [inputsMatrix, setInputsMatrix] = useState([[1, 1]])
  const [activeCellIndex, setActiveCellIndex] = useState(0);
  const [activeRowIndex, setActiveRowIndex] = useState(0);
  const inputsRefs = useRef([]);

  useEffect(() => {
    const handleKeyPress = (e) => {
      if (!e.metaKey) {
        return;
      }

      switch (e.key) {
        case 'ArrowUp': {
          setActiveRowIndex(prevState => prevState === 0 ? 0 : prevState - 1)

          break
        }
        case 'ArrowDown': {
          setActiveRowIndex(prevState => prevState + 1)

          break
        }
        case 'ArrowRight': {
          setActiveCellIndex(prevState => prevState + 1)

          break
        }
        case 'ArrowLeft': {
          setActiveCellIndex(prevState => prevState === 0 ? 0 : prevState - 1)

          break
        }
      }
    }

    window.addEventListener('keydown', handleKeyPress)

    return () => window.removeEventListener('keydown', handleKeyPress)
  }, [])

  useEffect(() => {
    const lastRow = inputsMatrix[activeRowIndex];

    if (!lastRow) {
      setInputsMatrix(prevState => {
        return [...prevState, prevState[activeRowIndex - 1]]
      })

      return
    }

    const lastEl = inputsMatrix[activeRowIndex][activeCellIndex];


    if (!lastEl) {
      setInputsMatrix(prevState => {
        return prevState.map((arr) => {
          arr.push(1)
          return arr
        })
      })
    }
  }, [activeCellIndex, activeRowIndex]);

  return (
    <div className="demo">
      {inputsMatrix.map((arr, arrIndex) => {
        return (
          <div className="row">
            {arr.map((item, itemIndex) => {
              return (
                <input type="text" className={itemIndex === activeCellIndex && arrIndex === activeRowIndex ? 'active' : ''} />
              )
            })}
          </div>
        )
      })}
    </div>
  )
}



export default function bootstrap(domElement) {
  const root = createRoot(domElement)
  root.render(<Demo/>)
}
